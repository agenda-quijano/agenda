export default function MyComponent() {
    return <h1>Hello</h1>
  }